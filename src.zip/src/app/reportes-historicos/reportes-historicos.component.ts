import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reportes-historicos',
  templateUrl: './reportes-historicos.component.html',
  styleUrls: ['./reportes-historicos.component.css']
})
export class ReportesHistoricosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
