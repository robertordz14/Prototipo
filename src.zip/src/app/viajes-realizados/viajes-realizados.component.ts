import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viajes-realizados',
  templateUrl: './viajes-realizados.component.html',
  styleUrls: ['./viajes-realizados.component.css']
})
export class ViajesRealizadosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
