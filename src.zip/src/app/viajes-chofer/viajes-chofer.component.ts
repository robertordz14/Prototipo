import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viajes-chofer',
  templateUrl: './viajes-chofer.component.html',
  styleUrls: ['./viajes-chofer.component.css']
})
export class ViajesChoferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
