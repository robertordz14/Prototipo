import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verificar-chofer',
  templateUrl: './verificar-chofer.component.html',
  styleUrls: ['./verificar-chofer.component.css']
})
export class VerificarChoferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
