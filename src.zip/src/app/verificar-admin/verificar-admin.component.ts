import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verificar-admin',
  templateUrl: './verificar-admin.component.html',
  styleUrls: ['./verificar-admin.component.css']
})
export class VerificarAdminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
